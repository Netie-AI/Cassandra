# CASSANDRA

A daily multi-agent research system that detects where the AI/semiconductor market sits on the
mania → blow-off arc, and outputs a single auditable **Crash Risk Score (CRS)** plus a written thesis.

Named for the prophet who saw the fall and couldn't make anyone believe the *timing*. That is the
exact failure mode this system is built to fight: being structurally right and tactically early.

---

## What it is (and what it is NOT)

**It IS:** a decision-support tool. Every morning you press `start`. It runs the same research loop
we developed by hand — parallel domain research, quantitative scoring, honest synthesis — and hands
you one report. You read it, you decide.

**It is NOT:**
- An auto-trader. It places no orders, touches no broker, moves no money. It produces a *score and a
  report*. The trade decision is yours, every time. This boundary is load-bearing — do not remove it.
- A crystal ball. The CRS is a *fragility gauge with a trigger overlay*, not a proven predictor. It
  tells you how loaded the spring is and whether something is pulling the trigger. It does not tell
  you the day. Treat it as a structured opinion-former, not a signal to fire on blindly.
- Financial advice. It is a personal research instrument. Backtest it before you trust it with size.

---

## The one idea the whole system is built on

A crash needs **two** things, and they are different:

1. **Fragility (F)** — how loaded the system is: leverage, valuation, sentiment, deteriorating breadth.
   This is the *spring*. It builds slowly and can stay loaded for a long time.
2. **Trigger (T)** — active catalyst pressure: Fed tightening, supply-side cracks, capex cuts.
   This is the *spark*.

`CRS` is built as `f(F, T)` with an **interaction term**, so that high fragility with no trigger
reads "loaded but no spark" (elevated, not imminent), and high-both reads "danger zone." This is the
mathematical fix to the single most common bubble-call error: confusing a loaded spring for a fired one.

**Corollary that answers "does the risk decay if months pass with no crash?"** — No, not with calendar
time. The score decays only if **fragility itself is falling** (`dF/dt < 0`). If margin debt keeps
climbing and capex stays debt-funded, five quiet months mean the spring is *more* loaded, not less.
The system tracks `dF/dt` explicitly (see `scoring.py::fragility_momentum`).

---

## What we deliberately did NOT include

- **Elliott Wave counts.** Unfalsifiable and fit-to-taste. The source doc leaned on "fifth wave
  complete" — that is exactly the part that blows up early traders. Excluded on purpose.
- **Precise crash-date prediction.** The model outputs a *level + confidence band + phase*, never
  "it crashes on date X." Anything claiming the date is lying to you.

The honest signals we DO trust (mechanical, historically reliable): margin debt, breadth divergence,
vol term structure, supply-side tells, the capex/revenue gap, credit-spread complacency.

---

## Repo map

```
cassandra/
  README.md              <- you are here
  ARCHITECTURE.md        <- agent topology, the DAG, data flow, run schedule, cost
  CRASH_SCORE_SPEC.md    <- THE MATH. Every formula. This is what to verify first.
  DATA_SOURCES.md        <- API map: what each provides, free vs paid, env vars, rate limits
  config/
    settings.example.yaml
  agents/
    orchestrator.md      <- the reasoning core (the "how we think" prompt)
    subagents.md         <- the 6 specialist prompts
  src/
    schemas.py           <- pydantic contracts between agents (the data contract)
    scoring.py           <- CRS math, implemented + runnable
    phase.py             <- Wyckoff phase state machine, implemented
    orchestrator.py      <- the daily run loop (skeleton with clear wiring points)
    tools/               <- API client stubs (Cursor fills these with your keys)
```

---

## Build order for Cursor (do these in sequence)

**Phase 0 — Scaffold.** `pip install` deps (anthropic, pydantic, httpx, pandas, numpy, pyyaml,
apscheduler). Wire `config/settings.example.yaml` → `settings.yaml`. Confirm `schemas.py` imports.

**Phase 1 — Data clients.** Implement the stubs in `src/tools/` one source at a time, free tiers
first (FRED, FINRA, Alpha Vantage). Each client returns the typed `MetricReading`s defined in
`schemas.py`. Unit-test each against a live key before moving on. **Do not** proceed to scoring until
the data contract is satisfied by real responses.

**Phase 2 — Scoring + phase.** `scoring.py` and `phase.py` are already implemented against the
schema. Feed them recorded fixtures, confirm the CRS reproduces the worked example in
`CRASH_SCORE_SPEC.md` (§9). This is the gate: if the example doesn't reproduce, the math is mis-wired.

**Phase 3 — Agents.** Wire the LLM calls in `orchestrator.py` using the prompts in `agents/`.
Orchestrator runs on `claude-opus-4-8`; high-volume subagent fetch/extraction runs on
`claude-sonnet-4-6` to control cost (see ARCHITECTURE §Cost).

**Phase 4 — Report + store.** `report.py` (Cursor-authored from the schema) renders the daily
markdown. Persist `DailyScore` to a timeseries store (SQLite to start; the CRS history is what makes
`dF/dt` and "what changed vs yesterday" possible).

**Phase 5 — Schedule.** APScheduler cron at your chosen time (after the prior US close + Asia open,
so the overnight tells from KOSPI/Taiwan are in). `start` = trigger a run now.

---

## Run

```bash
python -m src.orchestrator --run        # one full daily cycle now ("start")
python -m src.orchestrator --backtest   # replay over historical fixtures to calibrate weights
python -m src.orchestrator --schedule   # start the daily cron
```

Then send the generated report (and any weight changes) back for review — the scoring spec is
designed to be argued with.
